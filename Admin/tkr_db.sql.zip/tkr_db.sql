-- phpMyAdmin SQL Dump
-- version 4.8.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 05, 2019 at 11:17 AM
-- Server version: 10.1.33-MariaDB
-- PHP Version: 7.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tkr_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `matric_upgrade`
--

CREATE TABLE `matric_upgrade` (
  `matric_id` int(11) NOT NULL,
  `surname` text NOT NULL,
  `fullnames` text NOT NULL,
  `DOB` date NOT NULL,
  `Gender` text NOT NULL,
  `ID` text NOT NULL,
  `Contact_Number` text NOT NULL,
  `Guardian_Surname` text NOT NULL,
  `Guardian_Name` text NOT NULL,
  `Guardian_Contact_Number` text NOT NULL,
  `Guardian_Relationship` text NOT NULL,
  `Modules` text NOT NULL,
  `Student_Declaration` text NOT NULL,
  `Parent_Declaration` text NOT NULL,
  `id_photo` blob NOT NULL,
  `previous_result` blob NOT NULL,
  `certified_ID` blob NOT NULL,
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `matric_upgrade`
--

INSERT INTO `matric_upgrade` (`matric_id`, `surname`, `fullnames`, `DOB`, `Gender`, `ID`, `Contact_Number`, `Guardian_Surname`, `Guardian_Name`, `Guardian_Contact_Number`, `Guardian_Relationship`, `Modules`, `Student_Declaration`, `Parent_Declaration`, `id_photo`, `previous_result`, `certified_ID`, `status`) VALUES
(1, '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', 'registered'),
(2, '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', 'registered');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `student_ID` bigint(20) NOT NULL,
  `January` double NOT NULL DEFAULT '0',
  `February` double NOT NULL DEFAULT '0',
  `March` double NOT NULL DEFAULT '0',
  `April` double NOT NULL DEFAULT '0',
  `May` double NOT NULL DEFAULT '0',
  `June` double NOT NULL DEFAULT '0',
  `July` double NOT NULL DEFAULT '0',
  `August` double NOT NULL DEFAULT '0',
  `September` double NOT NULL DEFAULT '0',
  `October` double NOT NULL DEFAULT '0',
  `November` double NOT NULL DEFAULT '0',
  `December` double NOT NULL DEFAULT '0',
  `last_payment` date NOT NULL,
  `category` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `skill_application`
--

CREATE TABLE `skill_application` (
  `student_id` int(11) NOT NULL,
  `Surname` text NOT NULL,
  `Fullnames` text NOT NULL,
  `Initials` text NOT NULL,
  `Title` text NOT NULL,
  `Working` text NOT NULL,
  `Company_Working` text NOT NULL,
  `Years_Working` tinyint(4) NOT NULL,
  `Company_Occupation` text NOT NULL,
  `Highest_Grade_Passed` tinyint(4) NOT NULL,
  `Qualification` text NOT NULL,
  `ID` text NOT NULL,
  `Certified_ID` blob,
  `DOB` date NOT NULL,
  `Gender` text NOT NULL,
  `Marital_Status` text NOT NULL,
  `Residential_Address` text NOT NULL,
  `Res_Code` text NOT NULL,
  `Postal_Address` text NOT NULL,
  `Postal_Code` text NOT NULL,
  `Correspondence_Address` text NOT NULL,
  `Home_Telephone` text NOT NULL,
  `Work_Telephone` text NOT NULL,
  `Phone_Number` text NOT NULL,
  `Fax_Number` text NOT NULL,
  `Email` varchar(255) NOT NULL,
  `kin_surname` text NOT NULL,
  `kin_fullnames` text NOT NULL,
  `kin_initials` text NOT NULL,
  `relationship` text NOT NULL,
  `kin_home_telephone` text NOT NULL,
  `kin_phone_number` text NOT NULL,
  `kin_email` varchar(255) NOT NULL,
  `kin_ID` text NOT NULL,
  `kin_address` text NOT NULL,
  `Guardian_Surname` text NOT NULL,
  `Guardian_Name` text NOT NULL,
  `Guardian_Initials` text NOT NULL,
  `Guardian_Title` text NOT NULL,
  `Guardian_Occupation` text NOT NULL,
  `Guardian_ID` text NOT NULL,
  `Guardian_Relationship` text NOT NULL,
  `Guardian_Home_Telephone` text NOT NULL,
  `Guardian_Work_Telephone` text NOT NULL,
  `Guardian_Email` varchar(255) NOT NULL,
  `Guardian_Cellnumber` text NOT NULL,
  `declaration` text NOT NULL,
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tkr_afternoon_class`
--

CREATE TABLE `tkr_afternoon_class` (
  `class_id` int(11) NOT NULL,
  `Name` text NOT NULL,
  `Surname` text NOT NULL,
  `ID` bigint(20) NOT NULL,
  `Country` text NOT NULL,
  `Province` text NOT NULL,
  `City` text NOT NULL,
  `Physical_Address` text NOT NULL,
  `Code` text NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Home_Tel_Num` varchar(255) NOT NULL,
  `Phone_Number` varchar(255) NOT NULL,
  `Gender` enum('Male','Female') NOT NULL,
  `DOB` date NOT NULL,
  `Age` int(11) NOT NULL,
  `Medical_Condition_Status` text NOT NULL,
  `Medical_Condition_description` text NOT NULL,
  `Parent_Permission` text NOT NULL,
  `Date_of_Application` date NOT NULL,
  `Parent_Initials` varchar(20) NOT NULL,
  `Parent_Name` text NOT NULL,
  `Parent_Surname` text NOT NULL,
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `matric_upgrade`
--
ALTER TABLE `matric_upgrade`
  ADD PRIMARY KEY (`matric_id`);

--
-- Indexes for table `skill_application`
--
ALTER TABLE `skill_application`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `tkr_afternoon_class`
--
ALTER TABLE `tkr_afternoon_class`
  ADD PRIMARY KEY (`class_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `matric_upgrade`
--
ALTER TABLE `matric_upgrade`
  MODIFY `matric_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `skill_application`
--
ALTER TABLE `skill_application`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tkr_afternoon_class`
--
ALTER TABLE `tkr_afternoon_class`
  MODIFY `class_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
